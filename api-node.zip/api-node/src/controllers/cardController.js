const express = require('express');
const cardService = require('../services/cardService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/', authenticateToken, async(req, res) => {
    try {
        const cards = await cardService.getAll();
        res.json(cards);
    } 
    catch (err) {
        console.log(err);
        res.status(400).json({error: err.message});
    }   
})

router.post('/', async(req, res) =>{
    try {
        const {name,attack,defense,level,cost,description,urlImage} = req.body;
        const card = await cardService.register(name, attack, defense, level, cost, description,urlImage);
        res.json(card);
    } catch (err) {
        console.log(err);
        res.status(400).json({error: err.message});
    } 
})

module.exports = router;