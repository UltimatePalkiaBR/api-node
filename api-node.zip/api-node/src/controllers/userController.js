const express = require('express');
const userService = require('../services/userService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/', authenticateToken, async(req, res) => {
    try {
        const users = await userService.getAll();
        res.json(users);
    } 
    catch (err) {
        console.log(err);
        res.status(400).json({error: err.message});
    }   
})

router.post('/', async(req, res) =>{
    const {username, password} = req.body;
    const user = await userService.register(username,password);
    res.json(user);
})

router.post('/login', async(req, res) => {
    try{
        const {username, password} = req.body;
        const token = await userService.login(username, password);
        res.json({token: token});
    }
    catch (error){
        res.status(400).json({error: error.message});
    }
})

router.delete('/:username', authenticateToken, async(req, res)=>{
    try {
        const {username} = req.params;
        await userService.delete(username);
        res.sendStatus(200);
    }
    catch (error){
        res.status(400).json({error: error.message})
    }
})

module.exports = router;