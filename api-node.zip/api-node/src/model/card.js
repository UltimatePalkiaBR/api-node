const { Sequelize, DataTypes, UUID } = require('sequelize');
const sequelize = require('../config/database');

const Card = sequelize.define('Cards',
    {
        id:{
            type: DataTypes.UUIDV4,
            primaryKey: true,
        },
        name:{
            type: DataTypes.STRING,
            allowNull:false,
        },
        attack:{
            type: DataTypes.INTEGER,
            allowNull:false,
        },
        defense:{
            type: DataTypes.INTEGER,
            allowNull:false,
        },
        level:{
            type: DataTypes.INTEGER,
            allowNull:false,
        },
        cost:{
            type: DataTypes.INTEGER,
            allowNull:false,
        },
        description:{
            type: DataTypes.STRING,
            allowNull:false,
        },
        urlImage:{
            type: DataTypes.STRING,
            allowNull:false,
        }
    }
)

module.exports = Card;