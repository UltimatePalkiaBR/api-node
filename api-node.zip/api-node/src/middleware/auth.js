const jwt = require('jsonwebtoken');
const { extensions } = require('sequelize/lib/utils/validator-extras');

const SECRET_KEY = 'chave_secreta';

function authenticateToken(req, res, next){
    const authHeader = req.headers["authorization"];

    if (!authHeader){
        return res.sendStatus(401);
    }

    jwt.verify(authHeader, SECRET_KEY, (err,user)=>{
        if(err){
            return res.sendStatus(403);
        }
    
        next();
    })

}

module.exports = authenticateToken;