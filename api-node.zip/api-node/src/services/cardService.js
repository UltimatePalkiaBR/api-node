const BCrypt = require('bcrypt');
const CardRepository = require('../repositories/cardRepository');
const {v4: UUIDV4} = require('uuid');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'chave_secreta'

class CardService {
    async getAll(){ 
        return CardRepository.findAll();
    }

    async register(name, attack, defense, level, cost, description,urlImage){
        console.log(name)
        console.log(name.lenght)
        if (name === "" || name.lenght < 1 || name.lenght > 50) {
            throw new Error('Preencha o nome da carta com 1 a 50 caracteres');
        }

        if(attack < 0 || attack > 10) {
            throw new Error('Preencha um valor entre 0 e 10 para o ataque');
        }

        if(defense < 0 || defense > 10) {
            throw new Error('Preencha um valor entre 0 e 10 para a defesa');
        }

        if(level < 1 || level > 5) {
            throw new Error('Preencha um valor entre 1 e 5 para o nível');
        }

        if(cost < 1 || cost > 10) {
            throw new Error('Preencha um valor entre 1 e 10 para o custo');
        }

        if(description.lenght < 1 || description.lenght > 250) {
            throw new Error('Preencha a descrição da carta com 1 a 250 caracteres');
        }

        if(urlImage.lenght < 11 || urlImage.lenght > 200) {
            throw new Error('Preencha a url da imagem com 11 a 200 caracteres');
        }

        const id = UUIDV4();

        return await CardRepository.createCard({id,name,attack,defense,level,cost,description,urlImage})
    }

    
}

module.exports = new CardService();