const bcrypt = require('bcrypt');
const userRepository = require('../repositories/userRepository');
const { v4: UUIDV4} = require('uuid')
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'chave_secreta'

class UserService{
    async getAll(){
        return userRepository.findAll();
    }

    async getByUserName(username){
        return userRepository.findByUserName(username);
    }

    async register(username, password){
        if(username === ""){
            throw new Error('Preencha o username!');
        }

        if(password === ""){
            throw new Error('Preencha a senha!');
        }

        const user = await this.getByUserName(username);

        if(user){
            throw new Error('Username indisponível');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const id = UUIDV4();
        return await userRepository.createUser({
            id,
            username,
            password: hashedPassword
        });

    }

    async login(username, password){
        const user = await this.getByUserName(username);
        if(!user){
            throw new Error('Usuário ou Senha Inválidos');
        }

        const isValidPassword = await bcrypt.compare(password, user.password)
        if(!isValidPassword){
            throw new Error('Usuário ou Senha inválidos');
        }
        const token =jwt.sign({id: user.id}, SECRET_KEY, {expiresIn: '1h'})
        return token;

    }

    async delete(username){
        const user = await this.getByUserName(username);

        if(!user){
            throw new Error('Usuário inválido');
        }

        userRepository.delete(user.id);
    }
}

module.exports = new UserService();