const Card = require('../model/card');

class CardRepository {
    async createCard(card)
    {
        return await Card.create(card);
    }

    async findAll()
    {
        return await Card.findAll();
    }
}

module.exports = new CardRepository();